<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Page Title</title>
<link rel="stylesheet" href="style.css">
<style>
html, body {
    margin: 0;
    padding: 0;
}    
 div{
    margin:0;
    display: block;
}
.button {
    width:70%;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin-bottom: 5%;
    margin-top: 5%;
    margin-left: 15%;
    margin-right: 15%;
  cursor: pointer;
    background: rgb(2,0,36);
background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(43,9,121,1) 100%, rgba(0,212,255,1) 100%);
}
.button:hover {
  background-color: #ddd;
  color: black;
}
.button1 {
    width:70%;
  border: none;
  color: black;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin-bottom: 5%;
    margin-top: 5%;
    margin-left: 15%;
    margin-right: 15%;
  cursor: pointer;
    background-color: white;
}
.div1{
    float:left;
    width: 19.8%;
    height: 90vh;
    background-color: blue;
    border-width:0px 2px 0px 0px;
    border-style:solid;
    border-color:white;
}
.div1_1{
background: rgb(20,64,207);
background: linear-gradient(90deg, rgba(20,64,207,1) 0%, rgba(0,212,255,1) 47%);
   
    color:white;
    
    width:100%;
    height: 50vh;
}
.div1_2{
    background: rgb(20,64,207);
background: linear-gradient(90deg, rgba(20,64,207,1) 0%, rgba(0,212,255,1) 47%);
    color:white;
    width:100%;
    height: 50vh;
}
.div2{
    background-color:#00d4ff;
    color:white;
    width:79%;
    float:left;
    padding-left: 1%;
    height: 3vh;
    border-width:0px 0px 2px 0px;
    border-style:solid;
    border-color:white;
}
.div3{
    background: #00d4ff;

    color:black;width:79%;float:left;padding-left: 1%;height:80vh;height: 95.6vh;
}
.login{
   background: rgb(2,0,36);background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(1,87,126,1) 56%, rgba(1,112,152,1) 100%, rgba(0,212,255,1) 100%);color:white;height:3vh;     
}
.wszystko{
        
}
</style>
</head>
<body>
<div class="login">
<!-- Tu logowanie -->
<form style="float:right;">
  <label for="Login">Login:</label>
  <input type="text" id="Login" name="Login">
  <label for="haslo">Hasło:</label>
  <input type="text" id="haslo" name="haslo">
</form>
</div>
<div class="div1">
    <div class ="div1_1">
        <a href="Main.html"><button class="button" >Main</button></a><br>
        <a href="Profil.html"><button class="button" >Profil</button></a><br>
        <button class="button button3">Obserowowani</button><br>
    </div>
    <div class ="div1_2">
    <a href="Atlas.php"><button class="button1 ">Atlas</button></a><br>
    <a href="DodajDoAtlasu.php"><button class="button">Dodaj do Atlasu</button> </a><br>
    <button class="button">Temp3</button><br>
</div>  
</div>

<div class ="div2">
    <form action="/action_page.php" style="float:left;">
        <label for="sort">Szukaj:</label>
        <input type="text" id="Szukaj" name="Szukaj">
        <input type="submit" value="OK" style="margin-right: 10px;">
    </form>
    <form action="/action_page.php" style="float:left;">
            <label for="sort">Po czym sortować:</label>
            <select name="sort" id="sort">
                <option value="zdjencia">Zdjęcia</option>
                <option value="ocena">Ocena</option>
                <option value="l_komentarzy">Liczba Komentarzy</option>
            </select>
        <input type="submit" value="OK">
    </form>   
</div>

<div class ="div3" style="padding-top:4px;">
<form method="post" action="2-search.php">
  <input type="text" name="search" required/>
  <input onclick="myFunction()" type="submit" value="Search"/>
</form>
 
    
<div id="Wszystko">

</div>    

</div> 
<script>
function myFunction() {
  document.getElementById("Wszystko").innerHTML = "";
}
</script>
 
</body>
</html>