<?php

	session_start();
	
	if (isset($_POST['email']))
	{
		$wszystko_OK=true;
		
		//Sprawdź poprawność loginu
		$nick = $_POST['nick'];
		
		//Sprawdzenie długości loginu (3-26 znaków)
		if ((strlen($nick)<3) || (strlen($nick)>26))
		{
			$wszystko_OK=false;
			$_SESSION['e_nick']="Login musi posiadać od 3 do 26 znaków!";
		}
		
		if (ctype_alnum($nick)==false)
		{
			$wszystko_OK=false;
			$_SESSION['e_nick']="Login może składać się tylko z liter i cyfr (bez polskich znaków)<br>Nie mniej niż 3 i nie więcej niż 26 znaków!";
		}
		
		// Sprawdź poprawność adresu email
		$email = $_POST['email'];
		$emailB = filter_var($email, FILTER_SANITIZE_EMAIL);
		
		if ((filter_var($emailB, FILTER_VALIDATE_EMAIL)==false) || ($emailB!=$email))
		{
			$wszystko_OK=false;
			$_SESSION['e_email']="Podaj poprawny adres e-mail!";
		}
		
		//Sprawdź poprawność hasła
		$haslo1 = $_POST['haslo1'];
		$haslo2 = $_POST['haslo2'];
		
		if ((strlen($haslo1)<3) || (strlen($haslo1)>32))
		{
			$wszystko_OK=false;
			$_SESSION['e_haslo']="Hasło musi posiadać od 3 do 32 znaków!";
		}
		
		if ($haslo1!=$haslo2)
		{
			$wszystko_OK=false;
			$_SESSION['e_haslo']="Podane hasła nie są identyczne!";
		}	

		
		
		//Czy zaakceptowano regulamin?
		if (!isset($_POST['regulamin']))
		{
			$wszystko_OK=false;
			$_SESSION['e_regulamin']="Potwierdź akceptację regulaminu!";
		}				
		
		
		
		//Zapamiętaj wprowadzone dane
		$_SESSION['fr_nick'] = $nick;
		$_SESSION['fr_email'] = $email;
		$_SESSION['fr_haslo1'] = $haslo1;
		$_SESSION['fr_haslo2'] = $haslo2;
		if (isset($_POST['regulamin'])) $_SESSION['fr_regulamin'] = true;
		
		require_once "connect.php";
		mysqli_report(MYSQLI_REPORT_STRICT);
		
		try 
		{
			$polaczenie = new mysqli($host, $db_user, $db_password, $db_name);
			if ($polaczenie->connect_errno!=0)
			{
				throw new Exception(mysqli_connect_errno());
			}
			else
			{
				//Czy email już istnieje?
				$rezultat = $polaczenie->query("SELECT Id_uzytkownika FROM uzytkownicy_io WHERE Email='$email'");
				
				if (!$rezultat) throw new Exception($polaczenie->error);
				
				$ile_takich_maili = $rezultat->num_rows;
				if($ile_takich_maili>0)
				{
					$wszystko_OK=false;
					$_SESSION['e_email']="Istnieje już konto przypisane do tego adresu e-mail!";
				}		

				//Czy login jest już zajęty?
				$rezultat = $polaczenie->query("SELECT Id_uzytkownika FROM uzytkownicy_io WHERE Login='$nick'");
				
				if (!$rezultat) throw new Exception($polaczenie->error);
				
				$ile_takich_nickow = $rezultat->num_rows;
				if($ile_takich_nickow>0)
				{
					$wszystko_OK=false;
					$_SESSION['e_nick']="Istnieje już gracz o takim nicku! Wybierz inny.";
				}
				
				if ($wszystko_OK==true)
				{
					//Wszystkie testy zaliczone, dodajemy użytkownika do bazy
					
					if ($polaczenie->query("INSERT INTO uzytkownicy_io VALUES (NULL, '$nick', '$haslo1', '$email')"))
					{
						$_SESSION['udanarejestracja']=true;
						header('Location: Start.php');
					}
					else
					{
						throw new Exception($polaczenie->error);
					}
					
				}
				
				$polaczenie->close();
			}
			
		}
		catch(Exception $e)
		{
			echo '<span style="color:red;">Błąd serwera! Przepraszamy za niedogodności i prosimy o rejestrację w innym terminie!</span>';
			echo '<br />Informacja developerska: '.$e;
		}
		
	}
	
	
?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Page Title</title>

<style>
html, body {
    margin: 0;
    padding: 0;
}    
 div{
    margin:0;
    display: block;
}
.button {
    width:70%;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin-bottom: 5%;
    margin-top: 5%;
    margin-left: 15%;
    margin-right: 15%;
  cursor: pointer;
   background-color: black;
}

.button1 {
    width:70%;
  border: none;
  color: black;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin-bottom: 5%;
    margin-top: 5%;
    margin-left: 15%;
    margin-right: 15%;
  cursor: pointer;
    background-color: white;
}
.div1{
    float:left;
    width: 19.8%;
    height: 90vh;
    background-color: blue;
    border-width:0px 2px 0px 0px;
    border-style:solid;
    border-color:white;
}
.div1_1{
background: rgb(20,64,207);
background: linear-gradient(90deg, rgba(20,64,207,1) 0%, rgba(0,212,255,1) 47%);
   
    color:white;
    
    width:100%;
    height: 50vh;
}
.div1_2{
    background: rgb(20,64,207);
background: linear-gradient(90deg, rgba(20,64,207,1) 0%, rgba(0,212,255,1) 47%);
    color:white;
    width:100%;
    height: 50vh;
}
.div2{
    background-color:#00d4ff;
    color:white;
    width:79%;
    float:left;
    padding-left: 1%;
    height: 3vh;
    border-width:0px 0px 2px 0px;
    border-style:solid;
    border-color:white;
}
.div3{
    background: #00d4ff;

    color:black;width:79%;float:left;padding-left: 1%;height:80vh;height: 97vh;
}
.login{
   background: rgb(2,0,36);background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(1,87,126,1) 56%, rgba(1,112,152,1) 100%, rgba(0,212,255,1) 100%);color:white;height:3vh;     
}
</style>
</head>
<body>
<div class="div1">
    <div class ="div1_1">
        <button class="button" >Main</button><br>
        <button class="button" >Profil</button><br>
        <button class="button button3">Obserowowani</button><br>
    </div>
    <div class ="div1_2">
    <button class="button ">Atlas</button><br>
    <button class="button">Dodaj do Atlasu</button> <br>
    <button class="button">Temp3</button><br>
</div>  
</div>

<div class ="div2">
    <form action="/action_page.php" style="float:left;">
        <label for="sort">Szukaj:</label>
        <input type="text" id="Szukaj" name="Szukaj">
        <input type="submit" value="OK" style="margin-right: 10px;">
    </form>
    <form action="/action_page.php" style="float:left;">
            <label for="sort">Po czym sortować:</label>
            <select name="sort" id="sort">
                <option value="zdjencia">Zdjęcia</option>
                <option value="ocena">Ocena</option>
                <option value="l_komentarzy">Liczba Komentarzy</option>
            </select>
        <input type="submit" value="OK">
    </form>   
</div>

<div class ="div3">
<form method="post">
	
		Login: <br /> <input type="text" value="<?php
			if (isset($_SESSION['fr_nick']))
			{
				echo $_SESSION['fr_nick'];
				unset($_SESSION['fr_nick']);
			}
		?>" name="nick" /><br />
		
		<?php
			if (isset($_SESSION['e_nick']))
			{
				echo '<div class="error">'.$_SESSION['e_nick'].'</div>';
				unset($_SESSION['e_nick']);
			}
		?>
		
		E-mail: <br /> <input type="text" value="<?php
			if (isset($_SESSION['fr_email']))
			{
				echo $_SESSION['fr_email'];
				unset($_SESSION['fr_email']);
			}
		?>" name="email" /><br />
		
		<?php
			if (isset($_SESSION['e_email']))
			{
				echo '<div class="error">'.$_SESSION['e_email'].'</div>';
				unset($_SESSION['e_email']);
			}
		?>
		
		Twoje hasło: <br /> <input type="password"  value="<?php
			if (isset($_SESSION['fr_haslo1']))
			{
				echo $_SESSION['fr_haslo1'];
				unset($_SESSION['fr_haslo1']);
			}
		?>" name="haslo1" /><br />
		
		<?php
			if (isset($_SESSION['e_haslo']))
			{
				echo '<div class="error">'.$_SESSION['e_haslo'].'</div>';
				unset($_SESSION['e_haslo']);
			}
		?>		
		
		Powtórz hasło: <br /> <input type="password" value="<?php
			if (isset($_SESSION['fr_haslo2']))
			{
				echo $_SESSION['fr_haslo2'];
				unset($_SESSION['fr_haslo2']);
			}
		?>" name="haslo2" /><br />
		
		<label>
			<input type="checkbox" name="regulamin" <?php
			if (isset($_SESSION['fr_regulamin']))
			{
				echo "checked";
				unset($_SESSION['fr_regulamin']);
			}
				?>/> Akceptuję <a href='regulamin.txt' target='_blanked'>regulamin</a>
		</label>
		
		<?php
			if (isset($_SESSION['e_regulamin']))
			{
				echo '<div class="error">'.$_SESSION['e_regulamin'].'</div>';
				unset($_SESSION['e_regulamin']);
			}
		?>	
		<br><br>

		<input type="submit" value="Zarejestruj się" /><br>
		
	</form>
Posiadasz już konto? <a href='Start.php' style='color: red;'>Zaloguj się tutaj!</a><br>

</div> 
  
</body>
</html>