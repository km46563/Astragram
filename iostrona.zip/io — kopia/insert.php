<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "km46563");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$Nazwa= mysqli_real_escape_string($link, $_REQUEST['Nazwa']);
$Opis = mysqli_real_escape_string($link, $_REQUEST['Opis']);
$Masa = mysqli_real_escape_string($link, $_REQUEST['Masa']);
$OdlegloscZ = mysqli_real_escape_string($link, $_REQUEST['Odleglosc_od_Ziemi']);
$OdlegloscS = mysqli_real_escape_string($link, $_REQUEST['Odleglosc_od_Slonca']);
$Objetosc = mysqli_real_escape_string($link, $_REQUEST['Objetosc']);
 
// Attempt insert query execution
$sql = "INSERT INTO `cialoniebieskie_io`(`Id_CialaNiebieskiego`, `Nazwa`, `Opis`, `Masa`, `Odleglosc_od_Ziemi`, `Odleglosc_od_Slonca`, `Objetosc`) VALUES ('NULL','$Nazwa','$Opis','$Masa','$OdlegloscZ','$OdlegloscS','$Objetosc')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
header('Location: DodajDoAtlasu.php');
?>